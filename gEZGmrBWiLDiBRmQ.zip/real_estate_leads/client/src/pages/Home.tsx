import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { CheckCircle2, Home as HomeIcon, Building2, Warehouse, AlertCircle } from "lucide-react";
import { Toaster, toast } from "sonner";

export default function Home() {
  const [formData, setFormData] = useState({
    name: "",
    phone: "",
    email: "",
    propertyType: "",
    propertyCondition: "",
    location: "",
    notes: "",
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitSuccess, setSubmitSuccess] = useState(false);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    // Validate required fields
    if (!formData.name || !formData.phone || !formData.email || !formData.propertyType) {
      toast.error("Please fill in all required fields");
      return;
    }

    setIsSubmitting(true);

    try {
      // Using Web3Forms - free form submission service
      const formPayload = new FormData();
      formPayload.append("access_key", "YOUR_WEB3FORMS_KEY_HERE");
      formPayload.append("name", formData.name);
      formPayload.append("phone", formData.phone);
      formPayload.append("email", formData.email);
      formPayload.append("propertyType", formData.propertyType);
      formPayload.append("propertyCondition", formData.propertyCondition);
      formPayload.append("location", formData.location);
      formPayload.append("notes", formData.notes);

      const response = await fetch("https://api.web3forms.com/submit", {
        method: "POST",
        body: formPayload,
      });

      if (response.ok) {
        setSubmitSuccess(true);
        setFormData({
          name: "",
          phone: "",
          email: "",
          propertyType: "",
          propertyCondition: "",
          location: "",
          notes: "",
        });
        toast.success("Thank you! We'll contact you soon with an offer.");
        setTimeout(() => setSubmitSuccess(false), 5000);
      } else {
        toast.error("Failed to submit form. Please try again.");
      }
    } catch (error) {
      console.error("Form submission error:", error);
      toast.error("An error occurred. Please try again later.");
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white">
      <Toaster />

      {/* Navigation */}
      <nav className="border-b border-slate-700 bg-slate-900/50 backdrop-blur">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="text-2xl font-bold text-blue-400">
            We Buy Real Estate
          </div>
          <div className="text-sm text-slate-300">Any Condition • Any Type</div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-4 py-16 md:py-24">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Sell Your Property Fast
              <span className="text-blue-400"> Without the Hassle</span>
            </h1>
            <p className="text-xl text-slate-300 mb-8">
              Whether you're facing foreclosure, need to relocate, want to retire, or just need to exit quickly—we buy all types of properties in any condition.
            </p>
            <div className="flex gap-4">
              <Button
                size="lg"
                className="bg-blue-500 hover:bg-blue-600 text-white"
                onClick={() => document.getElementById("form-section")?.scrollIntoView({ behavior: "smooth" })}
              >
                Get a Free Offer
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-slate-400 text-slate-300 hover:bg-slate-800"
              >
                Learn More
              </Button>
            </div>
          </div>

          {/* Quick Stats */}
          <div className="space-y-4">
            <Card className="bg-slate-800 border-slate-700 p-6">
              <div className="flex items-start gap-4">
                <CheckCircle2 className="w-8 h-8 text-green-400 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-lg mb-2">Fast Closing</h3>
                  <p className="text-slate-300">Close in as little as 7-14 days</p>
                </div>
              </div>
            </Card>
            <Card className="bg-slate-800 border-slate-700 p-6">
              <div className="flex items-start gap-4">
                <CheckCircle2 className="w-8 h-8 text-green-400 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-lg mb-2">No Repairs Needed</h3>
                  <p className="text-slate-300">We buy properties in any condition</p>
                </div>
              </div>
            </Card>
            <Card className="bg-slate-800 border-slate-700 p-6">
              <div className="flex items-start gap-4">
                <CheckCircle2 className="w-8 h-8 text-green-400 flex-shrink-0 mt-1" />
                <div>
                  <h3 className="font-semibold text-lg mb-2">No Commissions</h3>
                  <p className="text-slate-300">No realtor fees or hidden costs</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Property Types Section */}
      <section className="bg-slate-800/50 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">
            We Buy All Property Types
          </h2>
          <div className="grid md:grid-cols-4 gap-6">
            <Card className="bg-slate-700 border-slate-600 p-8 text-center hover:border-blue-400 transition">
              <HomeIcon className="w-12 h-12 mx-auto mb-4 text-blue-400" />
              <h3 className="font-semibold text-lg mb-2">Single Family Homes</h3>
              <p className="text-slate-300 text-sm">Residential properties of any size</p>
            </Card>
            <Card className="bg-slate-700 border-slate-600 p-8 text-center hover:border-blue-400 transition">
              <Building2 className="w-12 h-12 mx-auto mb-4 text-blue-400" />
              <h3 className="font-semibold text-lg mb-2">Multifamily</h3>
              <p className="text-slate-300 text-sm">Apartments, duplexes, triplexes</p>
            </Card>
            <Card className="bg-slate-700 border-slate-600 p-8 text-center hover:border-blue-400 transition">
              <Warehouse className="w-12 h-12 mx-auto mb-4 text-blue-400" />
              <h3 className="font-semibold text-lg mb-2">Self-Storage</h3>
              <p className="text-slate-300 text-sm">Storage facilities & units</p>
            </Card>
            <Card className="bg-slate-700 border-slate-600 p-8 text-center hover:border-blue-400 transition">
              <Building2 className="w-12 h-12 mx-auto mb-4 text-blue-400" />
              <h3 className="font-semibold text-lg mb-2">Industrial-Flex</h3>
              <p className="text-slate-300 text-sm">Warehouses & commercial space</p>
            </Card>
          </div>
        </div>
      </section>

      {/* Lead Capture Form Section */}
      <section id="form-section" className="max-w-4xl mx-auto px-4 py-16">
        <div className="bg-slate-800 border border-slate-700 rounded-lg p-8 md:p-12">
          <h2 className="text-3xl font-bold mb-2">Get Your Free Offer</h2>
          <p className="text-slate-300 mb-8">
            Fill out the form below and we'll contact you within 24 hours with a no-obligation offer.
          </p>

          {submitSuccess ? (
            <div className="bg-green-900/30 border border-green-500 rounded-lg p-8 text-center">
              <CheckCircle2 className="w-16 h-16 mx-auto mb-4 text-green-400" />
              <h3 className="text-2xl font-bold mb-2">Thank You!</h3>
              <p className="text-slate-300 mb-4">
                We've received your information and will contact you soon with a free offer.
              </p>
              <p className="text-sm text-slate-400">
                Expected response time: Within 24 hours
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-6">
              {/* Name */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Full Name <span className="text-red-400">*</span>
                </label>
                <Input
                  type="text"
                  name="name"
                  value={formData.name}
                  onChange={handleInputChange}
                  placeholder="John Doe"
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                  required
                />
              </div>

              {/* Phone */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Phone Number <span className="text-red-400">*</span>
                </label>
                <Input
                  type="tel"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                  placeholder="(555) 123-4567"
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                  required
                />
              </div>

              {/* Email */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Email Address <span className="text-red-400">*</span>
                </label>
                <Input
                  type="email"
                  name="email"
                  value={formData.email}
                  onChange={handleInputChange}
                  placeholder="john@example.com"
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                  required
                />
              </div>

              {/* Property Type */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Property Type <span className="text-red-400">*</span>
                </label>
                <Select value={formData.propertyType} onValueChange={(value) => handleSelectChange("propertyType", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select property type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="single-family">Single Family Home</SelectItem>
                    <SelectItem value="multifamily">Multifamily (2-4 units)</SelectItem>
                    <SelectItem value="apartment-complex">Apartment Complex (5+ units)</SelectItem>
                    <SelectItem value="self-storage">Self-Storage</SelectItem>
                    <SelectItem value="industrial-flex">Industrial-Flex</SelectItem>
                    <SelectItem value="commercial">Other Commercial</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Property Condition */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Property Condition
                </label>
                <Select value={formData.propertyCondition} onValueChange={(value) => handleSelectChange("propertyCondition", value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select condition" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="excellent">Excellent</SelectItem>
                    <SelectItem value="good">Good</SelectItem>
                    <SelectItem value="fair">Fair</SelectItem>
                    <SelectItem value="poor">Poor / Needs Repairs</SelectItem>
                    <SelectItem value="distressed">Distressed / Foreclosure</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Location */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Property Location / City
                </label>
                <Input
                  type="text"
                  name="location"
                  value={formData.location}
                  onChange={handleInputChange}
                  placeholder="City, State or Address"
                  className="bg-slate-700 border-slate-600 text-white placeholder-slate-400"
                />
              </div>

              {/* Additional Notes */}
              <div>
                <label className="block text-sm font-medium mb-2">
                  Additional Information
                </label>
                <textarea
                  name="notes"
                  value={formData.notes}
                  onChange={handleInputChange}
                  placeholder="Tell us more about your situation (e.g., foreclosure, relocation, retirement, etc.)"
                  rows={4}
                  className="w-full bg-slate-700 border border-slate-600 text-white placeholder-slate-400 rounded-md px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-400"
                />
              </div>

              {/* Submit Button */}
              <Button
                type="submit"
                size="lg"
                disabled={isSubmitting}
                className="w-full bg-blue-500 hover:bg-blue-600 text-white font-semibold py-3"
              >
                {isSubmitting ? "Submitting..." : "Get Your Free Offer"}
              </Button>

              <p className="text-xs text-slate-400 text-center">
                We respect your privacy. Your information will only be used to contact you about your property.
              </p>
            </form>
          )}
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="bg-slate-800/50 py-16">
        <div className="max-w-6xl mx-auto px-4">
          <h2 className="text-4xl font-bold mb-12 text-center">Why Choose Us?</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div>
              <AlertCircle className="w-12 h-12 text-blue-400 mb-4" />
              <h3 className="text-xl font-semibold mb-3">No Contingencies</h3>
              <p className="text-slate-300">
                We buy as-is with no inspections, appraisals, or financing contingencies. What you see is what you get.
              </p>
            </div>
            <div>
              <CheckCircle2 className="w-12 h-12 text-blue-400 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Flexible Terms</h3>
              <p className="text-slate-300">
                We work with your timeline. Whether you need to close in days or weeks, we can accommodate.
              </p>
            </div>
            <div>
              <HomeIcon className="w-12 h-12 text-blue-400 mb-4" />
              <h3 className="text-xl font-semibold mb-3">Local Expertise</h3>
              <p className="text-slate-300">
                We know the local market and can provide fair offers based on current market conditions.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-slate-700 bg-slate-900 py-8">
        <div className="max-w-6xl mx-auto px-4 text-center text-slate-400">
          <p className="mb-2">© 2024 We Buy Real Estate Any Condition. All rights reserved.</p>
          <p className="text-sm">
            Helping property owners find quick solutions for their real estate challenges.
          </p>
        </div>
      </footer>
    </div>
  );
}
